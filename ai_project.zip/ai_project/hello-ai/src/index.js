export default {
	async fetch(request, env) {
		const url = new URL(request.url);

		const corsHeaders = {
			"Content-Type": "application/json",
			"Access-Control-Allow-Origin": "*",
			"Access-Control-Allow-Methods": "GET, POST, OPTIONS",
			"Access-Control-Allow-Headers": "Content-Type"
		};

		if (request.method === "OPTIONS") {
			return new Response(null, { status: 204, headers: corsHeaders });
		}

		if (request.method === "POST") {
			try {
				const formData = await request.formData();
				const userInput = formData.get("query") || "";
				let pageHtml = formData.get("page_html") || "";
				let selectedHtml = formData.get("selected_html") || "";

				// Cap page HTML size
				const maxLength = 5000;
				if (pageHtml.length > maxLength) {
					pageHtml = pageHtml.slice(0, maxLength);
				}

				let image = formData.get("image");
				let imageUrl = null;

				try {
					if (image && typeof image === "string" && image.startsWith("data:image/")) {
						const base64Data = image.split(",")[1];
						const mimeMatch = image.match(/^data:(image\/[^;]+);base64,/);
						const contentType = mimeMatch ? mimeMatch[1] : "image/png";
						const buffer = Uint8Array.from(atob(base64Data), c => c.charCodeAt(0));

						const imageId = crypto.randomUUID();
						const key = `uploads/${imageId}.png`;

						await env.AI_BUCKET.put(key, buffer, {
							httpMetadata: { contentType }
						});

						imageUrl = `https://${env.AI_BUCKET.ai - images}.r2.dev/${key}`;
					} else if (image) {
						console.warn("⚠️ Image format not recognized");
					}
				} catch (e) {
					console.error("🔥 Error handling image:", e);
				}

				console.log("Received form data:", {
					userInput,
					hasImage: !!imageUrl,
					selected: !!selectedHtml
				});

				// Check cache
				let cachedResponse = await checkCache(env.DB, userInput);
				if (!cachedResponse) {
					const aiResponse = await queryLlama3(env, userInput, imageUrl, pageHtml, selectedHtml);
					await storeInCache(env.DB, userInput, aiResponse, imageUrl);
					await storeInVectorIndex(env, userInput, aiResponse, imageUrl);
					cachedResponse = aiResponse;
				}

				return new Response(JSON.stringify({ response: cachedResponse }), {
					headers: corsHeaders
				});
			} catch (err) {
				console.error("🔥 Server error:", err.stack || err);
				return new Response(JSON.stringify({ error: "Internal Server Error" }), {
					status: 500,
					headers: corsHeaders
				});
			}
		}

		if (url.pathname === "/history") {
			const history = await getLastPrompts(env.DB);
			return new Response(JSON.stringify(history), { headers: corsHeaders });
		}

		return new Response(JSON.stringify({ error: "Invalid Request" }), {
			status: 400,
			headers: corsHeaders
		});
	},
};

async function queryLlama3(env, input, imageUrl, page_html, selectedHtml) {
	let prompt;

	if (selectedHtml && selectedHtml.trim().length > 0) {
		prompt = `You are modifying the following HTML element:\n\n${selectedHtml}\n\nApply this change: "${input}".\n\nReturn ONLY the modified HTML element.`;
	} else {
		prompt = `You are modifying this FULL HTML page:\n\n${page_html}\n\nApply this change: "${input}".\n\n⚠️ IMPORTANT: Return ONLY the updated full HTML document. Do NOT explain anything. Your response MUST begin with <!DOCTYPE html>.`;
	}

	if (imageUrl) {
		prompt += `\nAlso consider this image for context: ${imageUrl}`;
	}

	const result = await env.AI.run('@cf/meta/llama-3-8b-instruct', {
		messages: [
			{
				role: "system",
				content:
					"You are an expert web developer. Always return valid, executable HTML. Never include explanations. Only output the full updated HTML or HTML elements."
			},
			{ role: "user", content: prompt }
		],
		max_tokens: 1500
	});

	const response = result?.response?.trim();

	if (!response || !response.startsWith("<")) {
		console.warn("AI returned something unexpected:", response);
		return "<p style='color:red;'>⚠️ AI failed to return valid HTML.</p>";
	}

	return response;
}


async function storeInCache(db, userInput, aiResponse, imageUrl) {
	try {
		await db.prepare("INSERT INTO queries (user_input, ai_response, image) VALUES (?, ?, ?)")
			.bind(userInput, aiResponse, imageUrl)
			.run();
	} catch (err) {
		console.error("DB insert failed:", err);
	}
}

async function checkCache(db, userInput) {
	const { results } = await db
		.prepare("SELECT ai_response FROM queries WHERE user_input = ?")
		.bind(userInput)
		.all();
	return results.length > 0 ? results[0].ai_response : null;
}

async function getLastPrompts(db) {
	const { results } = await db
		.prepare("SELECT user_input FROM queries ORDER BY id DESC LIMIT 5")
		.all();
	return results.map((row) => row.user_input);
}

async function storeInVectorIndex(env, prompt, response, imageUrl) {
	try {
		const embedding = await env.AI.run('@cf/openai/text-embedding-ada-002', {
			input: prompt
		});

		if (!embedding || !embedding.data || !embedding.data[0]) {
			console.warn("No vector embedding returned.");
			return;
		}

		const vector = embedding.data[0].embedding;
		const metadata = {
			prompt,
			response,
			image: imageUrl || null,
			timestamp: Date.now()
		};

		await env.VECTORIZE_INDEX.insert([
			{
				id: crypto.randomUUID(),
				values: vector,
				metadata
			}
		]);
	} catch (err) {
		console.error("Vector insert failed:", err);
	}
}
