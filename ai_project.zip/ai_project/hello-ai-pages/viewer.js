let originalPageHtml = "";
function waitForFormAndInitialize() {
  const form = document.getElementById("ai-form");
  const queryInput = document.getElementById("query");

  if (!form || !queryInput) {
    setTimeout(waitForFormAndInitialize, 100);
    return;
  }

  console.log("✅ viewer.js initialized and event listener attached.");

  // 🔘 Element selection logic
  let selecting = false;

  const selectBtn = document.getElementById("select-element-btn");
  const hiddenInput = document.getElementById("selected-html");

  if (selectBtn && hiddenInput) {
    selectBtn.addEventListener("click", () => {
      selecting = true;
      alert("Click on any element in the page to select it.");
      document.body.style.cursor = "crosshair";

      const mouseHandler = (e) => {
        if (!selecting) return;

        e.preventDefault();
        e.stopPropagation();

        const el = e.target;
        el.style.outline = "2px solid red";
        setTimeout(() => (el.style.outline = ""), 800);

        hiddenInput.value = el.outerHTML;

        document.body.style.cursor = "default";
        selecting = false;
        document.removeEventListener("click", mouseHandler, true);
      };

      document.addEventListener("click", mouseHandler, true);
    });
  }

  // 📨 Submit handler
  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    const formData = new FormData(form);
    const query = formData.get("query");
    const fileInput = document.getElementById("image-upload");
    const file = fileInput?.files?.[0];

    if (!query.trim()) {
      alert("Please enter a prompt.");
      return;
    }

    const sendRequest = async () => {
      const clonedDoc = document.documentElement.cloneNode(true);
      const popupClone = clonedDoc.querySelector("#ai-popup");
      if (popupClone) popupClone.remove();
      originalPageHtml = clonedDoc.outerHTML; // ⬅️ save original full HTML here
      formData.append("page_html", originalPageHtml);

      try {
        const res = await fetch("https://hello-ai.rxt9df8x4t.workers.dev", {
          method: "POST",
          body: formData,
        });

        const data = await res.json();
        const preview = document.getElementById("preview-code");
        const popup = document.getElementById("ai-popup");
        const previewSection = document.getElementById("preview-section");
        const previewBtn = document.getElementById("preview-website-btn");
        const livePreview = document.getElementById("live-preview-frame");
        const livePreviewSection = document.getElementById("live-preview-section");

        if (data.response) {
          popup.classList.add("popup-expanded");
          console.log("AI RESPONSE:", data.response);

          if (preview) {
            preview.textContent = data.response;
            previewSection.style.display = "block";
          }

          if (previewBtn) {
            previewBtn.style.display = "inline-block";
            previewBtn.onclick = () => {
              const html = data.response || "";

              if (livePreview) {
                const doc = livePreview.contentDocument || livePreview.contentWindow.document;
                doc.open();
                const finalHtml = html.includes("<html")
                  ? html
                  : injectIntoFullPage(originalPageHtml, html);

                doc.write(finalHtml);
                setTimeout(() => {
                  if (!doc.body || !doc.body.innerHTML.trim()) {
                    document.getElementById("preview-error").style.display = "block";
                  } else {
                    document.getElementById("preview-error").style.display = "none";
                  }
                }, 500);
                

                doc.close();
              }

              if (livePreviewSection) {
                livePreviewSection.style.display = "block";
              }
            };
          }

        } else {
          if (preview) {
            preview.textContent = "No response";
          }
        }
      } catch (err) {
        console.error("Error sending request:", err);
        alert("Something went wrong.");
      }
    };

    if (file && file.size > 0) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        formData.set("image", reader.result);
        await sendRequest();
      };
      reader.readAsDataURL(file);
    } else {
      formData.delete("image");
      await sendRequest();
    }
  });

  // ❌ Close button
  const closeBtn = document.getElementById("close-popup");
  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      const popup = document.getElementById("ai-popup");
      popup.style.display = "none";
    });
  }
}

function wrapInHtmlShell(content) {
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Preview</title>
      <style>body { font-family: sans-serif; padding: 2rem; }</style>
    </head>
    <body>
      ${content}
    </body>
    </html>
  `;

}
function injectIntoFullPage(fullHtml, injectedContent) {
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(fullHtml, "text/html");

    const temp = document.createElement("div");
    temp.innerHTML = injectedContent.trim();
    const newEl = temp.firstElementChild;

    const oldEl = doc.querySelector(newEl.tagName);
    if (oldEl) {
      oldEl.replaceWith(newEl);
    } else {
      console.warn("Could not find element to replace. Appending instead.");
      doc.body.appendChild(newEl);
    }

    return "<!DOCTYPE html>\n" + doc.documentElement.outerHTML;
  } catch (err) {
    console.error("Error injecting HTML:", err);
    return wrapInHtmlShell(injectedContent);
  }
}


// 🔁 Start polling for the form once script loads
waitForFormAndInitialize();
