(async function () {
  const style = document.createElement('style');
  style.textContent = `
    #ai-chatbot-icon {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background-color: #cfb272;
      border-radius: 50%;
      width: 60px;
      height: 60px;
      z-index: 9999;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      font-size: 30px;
    }
  `;
  document.head.appendChild(style);

  // Inject Icon
  const icon = document.createElement('div');
  icon.id = 'ai-chatbot-icon';
  icon.textContent = '💬';
  document.body.appendChild(icon);

  async function loadPopupHtml() {
    try {
      const res = await fetch('https://hello-ai-pages.pages.dev/viewer.html');
      const html = await res.text();
  
      const wrapper = document.createElement('div');
      wrapper.innerHTML = html;
      wrapper.id = 'ai-chat-wrapper';
      document.body.appendChild(wrapper);
  
      const script = document.createElement("script");
      script.src = chrome.runtime.getURL("viewer.js");
      script.type = "text/javascript";
      script.defer = true;
      document.body.appendChild(script);
  
    } catch (err) {
      console.error('Failed to load popup HTML:', err);
    }
  }
  
  icon.onclick = async () => {
    const popup = document.getElementById('ai-popup');
    if (!popup) {
      await loadPopupHtml();
    } else {
      popup.style.display = popup.style.display === 'none' ? 'block' : 'none';
    }
  };
})();
