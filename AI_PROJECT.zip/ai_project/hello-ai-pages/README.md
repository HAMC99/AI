# 3DmodelsProject
Project used to inject the QR of a 3D model into a webpage based on the parameters in the URL.
