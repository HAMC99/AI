export default {
	async fetch(request, env) {
		const url = new URL(request.url);

		const corsHeaders = {
			"Content-Type": "application/json",
			"Access-Control-Allow-Origin": "*",
			"Access-Control-Allow-Methods": "GET, POST, OPTIONS",
			"Access-Control-Allow-Headers": "Content-Type"
		};

		if (request.method === "OPTIONS") {
			return new Response(null, { status: 204, headers: corsHeaders });
		}

		if (request.method === "POST") {
			try {
			  console.log("Receiving POST request");

			  let formData = await request.formData();
			  let userInput = formData.get("query") || "";
			  let imageUrl = formData.get("image");
			  imageUrl = imageUrl && imageUrl.trim() !== "" ? imageUrl : null;
			  let pageHtml = formData.get("page_html") || "";

			  console.log("Parsed formData:", { userInput, imageUrl, pageHtml });

			  let cachedResponse = await checkCache(env.DB, userInput);
			  if (!cachedResponse) {
				console.log("No cache found, querying LLaMA");
				let aiResponse = await queryLlama3(env, userInput, imageUrl, pageHtml);
				console.log("AI responded:", aiResponse);
				await storeInCache(env.DB, userInput, aiResponse, imageUrl);
				cachedResponse = aiResponse;
			  } else {
				console.log("Using cached response");
			  }

			  return new Response(JSON.stringify({ response: cachedResponse }), {
				headers: corsHeaders
			  });
			} catch (err) {
			  console.error("🔥 Server error:", err.stack || err);
			  return new Response(JSON.stringify({ error: "Internal Server Error" }), {
				status: 500,
				headers: corsHeaders
			  });
			}
		  }


		if (url.pathname === "/history") {
			let history = await getLastPrompts(env.DB);
			return new Response(JSON.stringify(history), { headers: corsHeaders });
		}

		return new Response(JSON.stringify({ error: "Invalid Request" }), {
			status: 400,
			headers: corsHeaders
		});
	},
};

async function queryLlama3(env, input, imageUrl, pageHtml) {
	let prompt = `Here is the HTML:\n\n${pageHtml}\n\nPerform the following update: "${input}". Return ONLY the updated HTML code or the specific changes.`;

	if (imageUrl) {
		prompt += `\nAlso, reference this image: ${imageUrl}`;
	}

	const result = await env.AI.run('@cf/meta/llama-3-8b-instruct', {
		messages: [
			{
				role: "system",
				content:
					"You are a web development assistant that edits and enhances HTML/CSS/JS based on user requests. Be precise and return only clean code or snippets."
			},
			{ role: "user", content: prompt }
		],
		max_tokens: 500
	});

	if (!result || !result.response) {
		console.error("AI response invalid:", result);
		return "AI returned no usable response.";
	}

	return result.response;
}

async function storeInCache(db, userInput, aiResponse, imageUrl) {
	try {
		await db
			.prepare(
				"INSERT INTO queries (user_input, ai_response, image) VALUES (?, ?, ?)"
			)
			.bind(userInput, aiResponse, imageUrl)
			.run();
	} catch (err) {
		console.error("DB insert failed:", err);
	}
}

async function checkCache(db, userInput) {
	let { results } = await db
		.prepare("SELECT ai_response FROM queries WHERE user_input = ?")
		.bind(userInput)
		.all();
	return results.length > 0 ? results[0].ai_response : null;
}

async function getLastPrompts(db) {
	let { results } = await db
		.prepare("SELECT user_input FROM queries ORDER BY id DESC LIMIT 5")
		.all();
	return results.map((row) => row.user_input);
}
